var Define = /** @class */ (function () {
    function Define() {
    }
    Define.UP = 1;
    Define.DOWN = 2;
    Define.LEFT = 3;
    Define.RIGHT = 4;
    Define.STONE = 1;
    Define.STRICK = 2;
    Define.EMPTYPLACE = 3;
    Define.PLAYER = 4;
    Define.DEBUG_NET = true;
    return Define;
}());
//# sourceMappingURL=onname.js.map